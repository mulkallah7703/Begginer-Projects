package Student;

public class Main {
	public static void main(String[] args) {
		Student student = new Student();
		UseStudent use = new UseStudent();
		
		student.getName();
		student.getAge();
		
		private static void printStudent (Student student) {
			try {
				System.out.println("Name: " + student.getName());
				System.out.println("age: " + student.getAge());
			} catch (NullPointerException e) {
				
			}
		
	}

}
