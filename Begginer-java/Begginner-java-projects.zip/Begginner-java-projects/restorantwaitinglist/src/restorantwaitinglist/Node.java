package restorantwaitinglist;

class Node {
	String Name; 
	String details;
	Node next;
	
	Node (String name, String details) {
		this.Name = name;
		this.details = details;
		this.next = null;
		
		
	}
	
	Node head;
	void LinkedList(){
		this.head = null;
		}
	
	void addFirstCustomer(String name, String details) {
		head = new Node(name, details);
	}
	
	void addCustomer(String name, String details) {
		Node newNode = new Node (name, details);
    	if (head == null) {
    		head = newNode;
    	}
    		
    	else {
    			Node current = head;
    			
    			while (current.next !=null) {
    				current = current.next;
    			}
    			current.next = newNode;
    		}
    	
	
	}
	
	
	}

