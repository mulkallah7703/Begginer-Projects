/**
 * 
 */
/**
 * 
 */
module restorantwaitinglist {
}