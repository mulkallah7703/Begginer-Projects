package polymorphsim;

public class Main {
	public static void main(String[] args) {
		
		int pageCount;
		String creator;
		String title;
		int durationMinutes;
		String gener;
		
		Book greatGatsbyBook = new Book (title= "The Great Gatsby", creator= "F. Scott Fitxgerald", pageCount= 180);
		
		Movie inceptionMovie = new Movie(title = "Inception", creator = "christopher Nolan", durationMinutes= 148);
		
		
		Music imaginMusic = new Music (title = "Imagin", creator = "johon lenon", gener = "Rock");
		
		MediaLibrary library = new MediaLibrary();
		
		Media addedBook = library.addMedia(greatGatsbyBook);
		Media addedMovie = library.addMedia(inceptionMovie);
		Media addedMusic = library.addMedia(imaginMusic);
		
		library.playMedia(addedBook);
		library.playMedia(addedMovie);
		library.playMedia(addedMusic);
	}

}
