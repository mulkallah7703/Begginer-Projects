package polymorphsim;

public class Music extends Media {
	String gnere;
			
			public Music(String title, String creator, String gnere) {
				super(title, creator);
				this.gnere = gnere;
				
			}

			@Override
			public void play() {
				// TODO Auto-generated method stub
				super.play();
				System.out.println("Listening" +title + "by" + creator +"in the" + gnere + "gnere");
			}

}
