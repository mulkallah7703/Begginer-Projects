package polymorphsim;

public class Movie extends Media {
	int durationMinutes;
		
		public Movie(String title, String creator, int durationMinutes) {
			super(title, creator);
			this.durationMinutes = durationMinutes;
			
		}

		@Override
		public void play() {
			// TODO Auto-generated method stub
			super.play();
			System.out.println("Reading" +title + "by" + creator +"Duration" + durationMinutes + "minutes");
		}

	}


