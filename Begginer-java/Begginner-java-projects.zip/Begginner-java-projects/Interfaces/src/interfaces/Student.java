package interfaces;

public class Student extends Person implements StudentInterface {
	String subject;
	int marks;
	    //TODO 5: add subject and marks attributes
	

	   public Student(String name, int age, String subject, int marks) {
	    	super(name, age);
	    	this.subject = subject;
	    	this.marks = marks;
	        //TODO 6: complete the constructor code
	    }

	    @Override
	   public void getDetails() {
	        super.getDetails();
	        System.out.println("subject = " + subject + "marks =" + marks);
	        //TODO 7: insert print statements for subject and marks attributes
	    }

	    
	



		public void result() {
	    	if (marks > 50) {
	    		System.out.println("Pass");
	    	}else {
	    		System.out.println("fail");
	    	}
	    	
	        //TODO 8: print Pass if marks>50, fail otherwise
	    }
		


	    public void fee(double amount) {
	    	System.out.println("Student pays the fees " + amount);
	    	}
	    

		@Override
		public void student() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void fee() {
			// TODO Auto-generated method stub
			
		}

		
	    	
	    	
	        //TODO 9: override fee() method to print the message
	        // the student has paid the specified fee as the argument.
	    }
	


