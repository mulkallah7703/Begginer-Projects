package interfaces;

public class Main {
    public static void main(String[] args) {
    	Student student = new Student("Charlie" , 20 , "Electronics" , 75);
    	
    	
        student.getDetails();
        student.result();
        student.fee(5000);
        
        System.out.println();
        //TODO 16: call result() and fee() methods
        Employee employee = new Employee ("Steve " ,35, 5000);
        //TODO 17: declare object of Employee class
        employee.getDetails();
     
        //TODO 18: call computeSalary() and computeTax() methods
    }
}


