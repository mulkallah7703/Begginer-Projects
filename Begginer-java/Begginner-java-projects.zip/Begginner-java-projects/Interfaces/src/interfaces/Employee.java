package interfaces;

	//TODO 10: make the Employee class implement EmployeeInterface
public class Employee extends Person implements EmployeeInterface{
	     int basicPay;
		//TODO 11: declare basicPay as int attribute
	  public  Employee(String name, int age, int basicPay ) {
	        super(name, age);
	        this.basicPay = basicPay;
	    }
	    @Override
	    public double computeSalary() {
	        
	        
	        //TODO 12: salary calculation logic goes here - basicPay+50 percent of basicPay
	        return  basicPay + (basicPay*0.5);
	    }
	    @Override
	    public double computeTax() {
	        
	        //TODO 13: tax is 10 percent of basicPay
	        return  basicPay * 0.10;
	    }
	    @Override
	    public void getDetails() {
	        super.getDetails();
	        System.out.println("Basic Pay: " + basicPay);
	        System.out.println("Salary: " + computeSalary());
	        System.out.println("Tax: " + computeTax());
	        //TODO 14: add print statements to print basicPay, salary and tax
	    }
	}


