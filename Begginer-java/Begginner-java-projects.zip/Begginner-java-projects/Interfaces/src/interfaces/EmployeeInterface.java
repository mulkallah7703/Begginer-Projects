package interfaces;

interface EmployeeInterface {
	double computeSalary();
	double computeTax();

	    //TODO 3: add computeSalary() and computeTax() methods
	}


