package interfaces;

public interface StudentInterface {
	abstract void student();
	abstract void fee();
	    //TODO 4: add result() and fee() as abstract methods
	}


