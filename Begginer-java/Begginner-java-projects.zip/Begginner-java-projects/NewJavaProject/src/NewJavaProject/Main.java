package NewJavaProject;

public class Main {
	public static void main (String[] args) {
		Electronics laptop = new Electronics("Laptop" , 1200, 12);
		Clothing tshirt = new Clothing("T-shirt", 20, "M");
		shopingcart cart = new shopingcart();
		
		cart.addItem(laptop);
		cart.addItem(tshirt);
	}

}
