package NewJavaProject;

public class shopingcart {
	public void addItem ( Product item) {
		item.displayInfo();
		System.out.println("Item added to cart. \n");
	}

}
