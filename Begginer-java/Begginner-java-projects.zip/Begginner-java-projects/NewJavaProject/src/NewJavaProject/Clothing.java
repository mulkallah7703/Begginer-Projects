package NewJavaProject;

public class Clothing extends Product {
	String size;
	
	public Clothing (String name, double price, String size) {
		super(name, price);
		this.size = size;
	}

	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		super.displayInfo();
	}

}
