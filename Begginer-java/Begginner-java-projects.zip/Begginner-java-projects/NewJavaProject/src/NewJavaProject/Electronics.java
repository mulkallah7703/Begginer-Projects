package NewJavaProject;

public class Electronics extends Product {
	int WarrantyPeriodInMonths;

	public Electronics(String name, double price, int warrantyPeriodInMonths) {
		super(name, price);
		this.WarrantyPeriodInMonths = WarrantyPeriodInMonths;
	}

	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		super.displayInfo();
		System.out.println("Warranty:" + WarrantyPeriodInMonths + "Months");
	}

}
