package Calculator;

import java.io.IOException;
import java.nio.CharBuffer;

public class File implements Readable {

	public File(String string) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int read(CharBuffer cb) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

}
