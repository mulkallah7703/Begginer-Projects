package Calculator;

import java.util.Scanner;


public class Calculator {
	int firstNumber;
	int secondNumber;
	
	int add() {
		return firstNumber + secondNumber;
	}
	void readNumbersFromFile() {
		Scanner fileScanner = new Scanner(new File("src/number.txt"));
		int firstNumber = fileScanner.nextInt();
		int secondNumber = fileScanner.nextInt();
		
	}

}
