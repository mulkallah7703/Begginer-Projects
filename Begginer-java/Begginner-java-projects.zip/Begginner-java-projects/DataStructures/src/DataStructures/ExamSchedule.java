package DataStructures;

public class ExamSchedule {
    private ExamNode head = null;
    private ExamNode current = null;

    public void addExam(String examDetails) {
        ExamNode newNode = new ExamNode(examDetails);

        if (head == null) {
            head = newNode;
            current = newNode;
        } else {
            ExamNode temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
        }
        System.out.println("Exam added: " + examDetails);
    }

    public void viewNextExam() {
        if (current == null) {
            System.out.println("No exams available.");
        } else if (current.next == null) {
            System.out.println("Next Exam: " + current.examDetails);
            System.out.println("You have reached the last exam.");
        } else {
            current = current.next;
            System.out.println("Next Exam: " + current.examDetails);
        }
    }

    public void viewPreviousExam() {
        if (current == null) {
            System.out.println("No exams available.");
        } else if (current.prev == null) {
            System.out.println("Previous Exam: " + current.examDetails);
            System.out.println("You are at the first exam.");
        } else {
            current = current.prev;
            System.out.println("Previous Exam: " + current.examDetails);
        }
    }

    public void viewAllExamSchedule() {
        if (head == null) {
            System.out.println("No exams scheduled.");
        } else {
            System.out.println("Exam Schedule:");
            ExamNode temp = head;
            while (temp != null) {
                System.out.println("- " + temp.examDetails);
                temp = temp.next;
            }
        }
    }
}
