package Arraystest;

public class Main {

	    public static void main(String [] args){
	        int [] daysInMonth = {30, 30, 29, 31,31, 30 ,30, 29, 29, 29, 30, 31};
	        String [] monthName = {"jan", "feb", "mar", "apr", "may","jun", "july" ,"ags","sep", "oct", "nov", 
	        "dec"};
	        for( int i=0; 1<daysInMonth.length; i++){
	        System.out.println(monthName[i] +"has" + daysInMonth[i] + "days");
	        }
	    }
	}


