package AccountingDiscipline;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	public static Connection connect() {
		Connection conn = null;
		try {
			String url = "jdbc:sqlite:accounting.db";
			conn = DriverManager.getConnection(url);
			System.out.println("Connected to SQL database!");
		} catch (SQLException e) {
			System.out.println("Connection failed!");
			e.printStackTrace();
		}
		return conn;
	}

}
