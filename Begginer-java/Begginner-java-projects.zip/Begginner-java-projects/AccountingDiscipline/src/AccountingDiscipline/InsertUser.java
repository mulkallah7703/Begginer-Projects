package AccountingDiscipline;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertUser {
	

	    public static void addUser(String username, String password, String role) {
	        String sql = "INSERT INTO Users(username, password, role) VALUES (?, ?, ?)";

	        try (Connection conn = DatabaseConnection.connect();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setString(1, username);
	            pstmt.setString(2, password);
	            pstmt.setString(3, role);

	            pstmt.executeUpdate();
	            System.out.println("✅ تم إضافة المستخدم بنجاح.");
	        } catch (SQLException e) {
	            System.out.println("❌ حدث خطأ أثناء إدخال المستخدم.");
	            e.printStackTrace();
	        }
	    }
	}



