package AccountingDiscipline;

public class JFrame {

	public static final String EXIT_ON_CLOSE = null;

}
