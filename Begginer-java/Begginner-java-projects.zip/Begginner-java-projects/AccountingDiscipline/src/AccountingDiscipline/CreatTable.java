package AccountingDiscipline;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;


public class CreatTable {

	    public static void createUsersTable() {
	        String sql = """
	            CREATE TABLE IF NOT EXISTS Users (
	                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
	                username TEXT NOT NULL UNIQUE,
	                password TEXT NOT NULL,
	                role TEXT NOT NULL
	            );
	        """;

	        try (Connection conn = DatabaseConnection.connect();
	             Statement stmt = conn.createStatement()) {
	            stmt.execute(sql);
	            System.out.println("✅ جدول Users تم إنشاؤه بنجاح.");
	        } catch (SQLException e) {
	            System.out.println("❌ فشل إنشاء جدول Users.");
	            e.printStackTrace();
	        }
	    }
	}



