package AccountingDiscipline;


public class Main {
	public static void main(String [] args) {
		DatabaseConnection.connect();
		CreatTable.createUsersTable();
		InsertUser.addUser("admin3", "admin454", "بياع");
		new LoginForm();
		CreateProductsTable.createTable();
		new ProductForm();
	}

}
