package AccountingDiscipline;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;


public class CreateProductsTable {


	    public static void createTable() {
	        String sql = """
	            CREATE TABLE IF NOT EXISTS Products (
	                product_id INTEGER PRIMARY KEY AUTOINCREMENT,
	                name TEXT NOT NULL,
	                description TEXT,
	                price REAL NOT NULL,
	                quantity INTEGER NOT NULL,
	                added_date TEXT
	            );
	        """;

	        try (Connection conn = DatabaseConnection.connect();
	             Statement stmt = conn.createStatement()) {

	            stmt.execute(sql);
	            System.out.println("✅ تم إنشاء جدول المنتجات بنجاح.");

	        } catch (SQLException e) {
	            System.out.println("❌ فشل في إنشاء جدول المنتجات.");
	            e.printStackTrace();
	        }
	    }
	


}
