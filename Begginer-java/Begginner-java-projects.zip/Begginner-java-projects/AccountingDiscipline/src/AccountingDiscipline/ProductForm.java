package AccountingDiscipline;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;


public class ProductForm extends JFrame {


	    private JTextField nameField, priceField, quantityField;
	    private JTextArea descriptionArea;
	    private JButton saveButton;

	    public ProductForm() {
	        setTitle("إضافة منتج");
	        setSize(400, 400);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setLocationRelativeTo(null);
	        setLayout(new GridLayout(6, 2, 10, 10));

	        nameField = new JTextField();
	        descriptionArea = new JTextArea(3, 20);
	        priceField = new JTextField();
	        quantityField = new JTextField();
	        saveButton = new JButton("حفظ المنتج");

	        add(new JLabel("اسم المنتج:"));
	        add(nameField);

	        add(new JLabel("الوصف:"));
	        

	        add(new JLabel("السعر:"));
	        add(priceField);

	        add(new JLabel("الكمية:"));
	        add(quantityField);

	        add(new JLabel("")); // مساحة فارغة
	        add(saveButton);

	        saveButton.addActionListener(e -> saveProduct());

	        setVisible(true);
	    }

	    private void setVisible(boolean b) {
			// TODO Auto-generated method stub
			
		}

		private void add(JButton saveButton2) {
			// TODO Auto-generated method stub
			
		}

		private void add(JTextField nameField2) {
			// TODO Auto-generated method stub
			
		}

		private void add(JLabel jLabel) {
			// TODO Auto-generated method stub
			
		}

		private void setLayout(GridLayout gridLayout) {
			// TODO Auto-generated method stub
			
		}

		private void setLocationRelativeTo(Object object) {
			// TODO Auto-generated method stub
			
		}

		private void setDefaultCloseOperation(String exitOnClose) {
			// TODO Auto-generated method stub
			
		}

		private void setSize(int i, int j) {
			// TODO Auto-generated method stub
			
		}

		private void setTitle(String string) {
			// TODO Auto-generated method stub
			
		}

		private void saveProduct() {
	        String name = nameField.getText();
	        String description = descriptionArea.getText();
	        double price;
	        int quantity = 0;

	        try {
	            price = Double.parseDouble(priceField.getText());
	            quantity = Integer.parseInt(quantityField.getText());
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(descriptionArea, this, "❌ تأكد من أن السعر والكمية أرقام صحيحة.", quantity);
	            return;
	        }

	        String date = LocalDate.now().toString();

	        String sql = "INSERT INTO Products(name, description, price, quantity, added_date) VALUES (?, ?, ?, ?, ?)";

	        try (Connection conn = DatabaseConnection.connect();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setString(1, name);
	            pstmt.setString(2, description);
	            pstmt.setDouble(3, price);
	            pstmt.setInt(4, quantity);
	            pstmt.setString(5, date);

	            pstmt.executeUpdate();
	            JOptionPane.showMessageDialog(descriptionArea, this, "✅ تم حفظ المنتج بنجاح!", quantity);
	            clearForm();

	        } catch (SQLException e) {
	            JOptionPane.showMessageDialog(descriptionArea, this, "❌ فشل في حفظ المنتج.", quantity);
	            e.printStackTrace();
	        }
	    }

	    private void clearForm() {
	        nameField.setText("");
	        descriptionArea.setText("");
	        priceField.setText("");
	        quantityField.setText("");
	    }
	}



