package AccountingDiscipline;

import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class LoginForm  extends JFrame{
	    private JTextField usernameField;
	    private JPasswordField passwordField;

	    public LoginForm() {
	        setTitle("تسجيل الدخول");
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setSize(300, 200);
	        setLocationRelativeTo(null); // وسط الشاشة
	        setLayout(new GridLayout(4, 1));

	        usernameField = new JTextField();
	        passwordField = new JPasswordField();

	        JButton loginButton = new JButton("تسجيل الدخول");

	        add(new JLabel("اسم المستخدم:"));
	        add(usernameField);
	        add(new JLabel("كلمة المرور:"));
	        add(passwordField);
	        add(loginButton);

	        loginButton.addActionListener(e -> login());

	        setVisible(true);
	    }

	    private void setVisible(boolean b) {
			// TODO Auto-generated method stub
			
		}

		private void add(JButton loginButton) {
			// TODO Auto-generated method stub
			
		}

		private void add(JTextField usernameField2) {
			// TODO Auto-generated method stub
			
		}

		private void add(JLabel jLabel) {
			// TODO Auto-generated method stub
			
		}

		private void setLayout(GridLayout gridLayout) {
			// TODO Auto-generated method stub
			
		}

		private void setLocationRelativeTo(Object object) {
			// TODO Auto-generated method stub
			
		}

		private void setSize(int i, int j) {
			// TODO Auto-generated method stub
			
		}

		private void setDefaultCloseOperation(String exitOnClose) {
			// TODO Auto-generated method stub
			
		}

		private void setTitle(String string) {
			// TODO Auto-generated method stub
			
		}

		private void login() {
	        String username = usernameField.getText();
	        String password = new String(passwordField.getPassword());

	        String sql = "SELECT * FROM Users WHERE username = ? AND password = ?";

	        try (Connection conn = DatabaseConnection.connect();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setString(1, username);
	            pstmt.setString(2, password);

	            ResultSet rs = pstmt.executeQuery();

	            if (rs.next()) {
	                String role = rs.getString("role");
	                JOptionPane.showMessageDialog(usernameField, this, "✅ تم تسجيل الدخول بنجاح كـ " + role, 0);
	                // افتح نافذة أخرى حسب الدور لاحقًا
	            } else {
	                JOptionPane.showMessageDialog(usernameField, this, "❌ اسم المستخدم أو كلمة المرور غير صحيحة", 0);
	            }
	        } catch (SQLException ex) {
	            ex.printStackTrace();
	        }
	    }
	}


	



