package Abstract;

public  class WatADriver extends Robot {

	@Override
	public void setChoice() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takeAction() {
		// TODO Auto-generated method stub
		
	}


	    /** TODO 12: Make this class "WatADriver"
	     *           a child class of
	     *           the "Robot" class
	     */

	    /** TODO 17: Implement the abstract methods
	     *           methods setChoice and takeAction
	     *           of the parent class "Robot"
	     */


	    /** TODO 18:  Inside the method "setChoice"
	     *             display
	     *            "Inside choice setting of WatADriver”
	     *            and
	     *            inside "takeAction" display “WatADriver will
	     *            drive or fly here”
	     */


	}




