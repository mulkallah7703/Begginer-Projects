package test;

public class Momeries {
	public static void main(String[] args)

	{
		System.out.println("hello i am mulk allah alsadi");
		System.out.println("my age is 22 years old");
	}
}
