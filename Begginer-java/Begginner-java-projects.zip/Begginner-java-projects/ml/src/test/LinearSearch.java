package test;

public class LinearSearch {
	public static void main(String[]args) {
		int [] array = {30,20,50,60,90,};
		int x=60;
		System.out.println(x+ "is present at:" + linSearch(array, array.length, x));
		
	}
	public static int linSearch (int[] list, int listLength, int key) {
		int loc;
		for (loc = 0;  loc<listLength; loc++) {
			if (list[loc]==key)
				return loc;
		}
		return-1;
	}

}
