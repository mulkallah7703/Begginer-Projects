package test;

public class TestDec2Bin {
	public static void main (String [] args) {
		int x = 65;
		System.out.println(x+"in Binary:" + dec2binRecursive(x) );
	}
	public static String dec2binRecursive(int n ) {
		if (n<2) 
			return n+"";
		else
			return dec2binRecursive(n/2) + n%2;
	}

}
