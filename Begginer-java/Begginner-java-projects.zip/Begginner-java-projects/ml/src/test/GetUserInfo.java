package test;
import java.util.Scanner;
public class GetUserInfo {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		String name;
		int a , b ;
		@SuppressWarnings("resource")
		Scanner kb = new Scanner (System.in);
				System.out.println("Enter your first value");
				a = kb.nextInt();
		b = kb.nextInt();
		System.out.println( a + "+" + b + "=" +(a+b));
		System.out.println( a + "-" + b + "=" +(a-b));
		System.out.println( a + "*" + b + "=" +(a*b));
	}
}
