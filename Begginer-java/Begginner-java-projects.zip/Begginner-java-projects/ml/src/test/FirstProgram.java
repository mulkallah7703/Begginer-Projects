package test;

public class FirstProgram {
	public static void main(String[] args)
	{
	System.out.println("Hello reader.");
	System.out.println("First Java Application.");
	}

}
