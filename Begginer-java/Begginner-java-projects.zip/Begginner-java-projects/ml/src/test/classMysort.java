package test;
import java.util.Arrays;
import java.util.Collections;

public class classMysort {
	public static void main (String[] args) {
		int[] ary1 = {11, 31,21,1,61,41};
	    int[] ary2 = {22, 12,42, 52,26, 4};
	    System.out.println("Input Array 1 =" + Arrays.toString(ary1));
	    System.out.println("Input Array 2 =" + Arrays.toString(ary2));
	    Arrays.sort(ary1);
	    System.out.println("Sorted Array 1 =" + Arrays.toString(ary1));
	    bubbleSort(ary2, ary2.length);
	    System.out.println("Sorted Array 2 =" + Arrays.toString(ary2));
	}
	public static void bubbleSort(int[] list, int listLength) {
		int i, j, temp;
		for (i = 0; i< listLength; i++) 
			for (j= 0; j< (listLength-1) -i; j++)
				if (list[j] > list[j+1]) {
					temp = list[j];
					list[j]= list[j+1];
					list[j+1] = temp;
				}
		
	}
	

}
