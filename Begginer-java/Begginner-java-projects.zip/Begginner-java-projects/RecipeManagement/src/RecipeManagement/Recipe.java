package RecipeManagement;
import java.util.LinkedList;
import java.util.ListIterator;

public class Recipe {
	public static void main (String[] args) {
		LinkedList<String> recipeSteps = new LinkedList<>();
		recipeSteps.add("Preheat the oven to 350 F");
		recipeSteps.add("Mix flour and sugar.");
		recipeSteps.add("Add eggs and milk.");
		System.out.println("Recipe Steps: "  + recipeSteps);
		
		recipeSteps.addFirst("Gather all ingredients.");
		recipeSteps.addLast("Serve and enjoy.");
		System.out.println("Updated Recipe Steps: " + recipeSteps);
		
		recipeSteps.add(2, "Whisk the eggs before adding.");
        System.out.println("Recipe Steps after adding in the middle: " + recipeSteps);
        
        recipeSteps.removeFirst();
        System.out.println("Recipe Steps after removing first element: " + recipeSteps);
        
        recipeSteps.removeLast();
        System.out.println("Recipe Steps after removing the last step: " + recipeSteps);
        
        recipeSteps.remove(1);
        System.out.println("Recipe Steps after removing a step from the middle: " + recipeSteps);
        
        ListIterator<String> iterator = recipeSteps.listIterator();
        System.out.println("Traversing forward through the recipe:");
        while (iterator.hasNext()) {
        	System.out.println(iterator.next());
        	
        }
        
        System.out.println("\nTraversing backward through the recipe:");
        while (iterator.hasPrevious()) {
            System.out.println(iterator.previous());
        }
	}

}
