/**
 * 
 */
/**
 * 
 */
module myfirstjavaproject {
}