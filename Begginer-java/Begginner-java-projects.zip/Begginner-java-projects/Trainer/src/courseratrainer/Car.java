package courseratrainer;

public class Car {

	//Attributes define a car's properties
		String make ;
		String model ;
		String color ;
		public Car() {
			this.make = "Unknown";
			this.model = "Unknown";
			this.color = "Black";
		}
		public Car(String make, String model, String color) {
			this.make = make;
			this.model = model;
			this.color = color;
		}
		
	//Method to accelerate the Car
		public void accelerate() {
			System.out.println("THE car is accelerating!");
			
			
		}
	//Methode to turn the Car
		public void turn() {
			System.out.println("The car is turning");
		}
		public String toString() {
			return "Car{" +
		"make='" + make + '\'' +
		", model=" + model +'\'' +
		",Color='" + color + '\'' +
		'}';
		}

	
public static void main(String[] args) {
	Car colorado = new Car();
	colorado.make = "Chevrolet";
	colorado.model = "Colorado";
	colorado.color = "Red";
	
	colorado.accelerate();
	Car mustang = new Car("Ford" , " Mustang", "Blue," );
	mustang.turn();
	System.out.println(colorado);
	System.out.println(mustang);
	
}
}


