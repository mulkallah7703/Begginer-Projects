/**
 * 
 */
/**
 * 
 */
module MediaPlayer {
}