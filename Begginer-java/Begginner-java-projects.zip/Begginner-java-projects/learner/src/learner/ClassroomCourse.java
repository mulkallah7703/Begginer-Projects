package learner;

class ClassroomCourse {
	    //TODO 6: add instance variables
	String schoole;
	String session;
	int fee;


	    ClassroomCourse(Subject subject, String instructor, int fee,
	                    String school, String session) {
	        //TODO 7: call superclass constructor
	        //complete constructor code
	    	super();
	    	this.fee= fee;
	    	this.session = session;
	    	this.schoole = schoole;
	    	
	    	
	    }


		public ClassroomCourse() {
			// TODO Auto-generated constructor stub
		}



}
