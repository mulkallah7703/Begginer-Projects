package learner;

public class OnlineCourse extends Course {
	String lessons;
	int weeks;

	    //TODO 15: include videoLessons and weeks attributes
	    OnlineCourse(int fee, String instructor, Subject subject, String lessons, int weeks) {

	        super(subject, instructor, fee);
	        //TODO 16: initialize other attributes
	        this.lessons= lessons;
	        this.weeks = weeks;
	    }
	


}
