package learner;

interface Assessments {
		//TODO 10: add assignmentScore() method
	void assignmentScore();
		//TODO 11: add quizScore() method
	void quizScore();
		


}
