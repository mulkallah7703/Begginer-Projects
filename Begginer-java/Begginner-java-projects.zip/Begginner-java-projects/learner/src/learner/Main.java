package learner;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display course list and accept user choice
        System.out.println("Available courses:");
        System.out.println("1. Java");
        System.out.println("2. Java Online");
        System.out.println("3. JavaScript");
        System.out.println("4. JavaScript Online");

        System.out.print("Enter course code: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        String courseTitle = "";
        switch (choice) {
            case 1:
                courseTitle = "Java";
                break;
            case 2:
                courseTitle = "Java Online";
                break;
            case 3:
                courseTitle = "JavaScript";
                break;
            case 4:
                courseTitle = "JavaScript Online";
                break;
            default:
                System.out.println("Invalid course code.");
                return;
        }

        // Accept learner name
        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        // Reminder message for max marks
        boolean isOnline = courseTitle.contains("Online");
        if (isOnline) {
            System.out.println("Enter assignment marks (max 30 for online course):");
        } else {
            System.out.println("Enter assignment marks (max 100 for classroom course):");
        }
        double assignmentMark = scanner.nextDouble();

        if (isOnline) {
            System.out.println("Enter quiz marks (max 10 for online course):");
        } else {
            System.out.println("Enter quiz marks (max 30 for classroom course):");
        }
        double quizMark = scanner.nextDouble();

        // Create Subject and Course
        Subject subject = new Subject(courseTitle, 3); // arbitrary credit value
        Course course = new Course(subject, name, choice);
        course.subject = subject;
        course.assignmentMarks = (int) assignmentMark;
        course.quizMarks = (int) quizMark;

        // Create Learner object
        Learner learner = new Learner(name, 0, 0);
        learner.course = course;

        // Calculate grade
        double gradeScore = learner.calculateGrade();
        System.out.println("Grade score: " + gradeScore);

        // Display final result
        if (gradeScore >= 5.0) {
            System.out.println("Congratulations " + name + ". You have successfully passed the " + courseTitle + " course.");
        } else {
            System.out.println("Hello " + name + ". You have completed the " + courseTitle + " course.");
        }

        scanner.close();
    }
}
