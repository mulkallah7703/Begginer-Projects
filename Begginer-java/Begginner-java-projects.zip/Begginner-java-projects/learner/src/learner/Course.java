package learner;

 class Course {
	    //TODO 3: include instance variables for Course class and complete constructor code
	Subject subject;
	String instructor;
	int coursefee;
	int assignmentMarks;
	int quizMarks;

	   public Course(Subject subject2, String instructor2, int fee) {
	    	this.subject = subject;
	    	this.instructor= instructor;
	    	this.coursefee = coursefee;

	}

}
