package learner;
class Learner implements Assessments {
    String name;
    Course course;
    double gradeScore;

    public Learner(String name, double course, double gradeScore) {
        this.name = name;
        this.gradeScore = gradeScore;
    }

    @Override
    public void assignmentScore() {
        System.out.println("Assignment Marks: " + course.assignmentMarks);
    }

    @Override
    public void quizScore() {
        System.out.println("Quiz Marks: " + course.quizMarks);
    }

    public double calculateGrade() {
        String title = course.subject.title;
        double assignmentScore;
        double quizScore;

        if (title.contains("Online")) {
            assignmentScore = (course.assignmentMarks / 30.0) * 10.0;
            quizScore = (course.quizMarks / 10.0) * 10.0;
        } else {
            assignmentScore = (course.assignmentMarks / 100.0) * 10.0;
            quizScore = (course.quizMarks / 30.0) * 10.0;
        }

        gradeScore = (assignmentScore + quizScore) / 2.0;
        return gradeScore;
    }
}
