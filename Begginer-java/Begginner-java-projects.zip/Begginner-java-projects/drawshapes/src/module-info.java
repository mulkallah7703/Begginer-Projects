/**
 * 
 */
/**
 * 
 */
module drawshapes {
}