package drawshapes;
import java.util.Scanner;

abstract class Shape{
	public abstract float calculateArea();
	public abstract void draw();
	public abstract void lineColor();
	
	
}
class Rectangle extends Shape{
	private float width;
	private float height;
	
	Rectangle (float w, float h){
		this.width = w;
		this.height = h; 
		
		
	}

	@Override
	public float calculateArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lineColor() {
		// TODO Auto-generated method stub
		
	}
	
}
class Circle extends Shape{
	private float radius;
	
	Circle(float r){
		this.radius = r;
		
	}

	@Override
	public float calculateArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lineColor() {
		// TODO Auto-generated method stub
		
	}
}



public class Main {
	public static void main(String[] args) {
		Scanner keyBoard = new Scanner(System.in);
		float w = keyBoard.nextFloat();
		float h = keyBoard.nextFloat();
		Rectangle rec = new Rectangle(w,h);
		rec.draw();
		float r = keyBoard.nextFloat();
		Circle cr = new Circle(r);
		cr.draw();
		System.out.println("Calculating Area of Rectangle" );
		System.out.println("Enter Width: ");
		System.out.print("Enter height: ");
		System.out.println("Area: " +rec.calculateArea());
		System.out.println("Calculating Area of Circle: ");
		System.out.println("Enter radius: ");
		System.out.println("Area: " +cr.calculateArea());
		
	}

}
