/**
 * 
 */
/**
 * 
 */
module readingandwritingfromtxt {
}