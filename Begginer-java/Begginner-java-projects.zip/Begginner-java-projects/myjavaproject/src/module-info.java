/**
 * 
 */
/**
 * 
 */
module myjavaproject {
}