package trainer;

public class Main {
	public static void main ( String [] args) {
		Developer d1 = new Developer();
		d1.setName("Ali");
		System.out.println(d1.getName());
	}

}
