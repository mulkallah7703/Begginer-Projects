/**
 * 
 */
/**
 * 
 */
module java {
	requires java.desktop;
}