/**
 * 
 */
/**
 * 
 */
module BookManager {
}