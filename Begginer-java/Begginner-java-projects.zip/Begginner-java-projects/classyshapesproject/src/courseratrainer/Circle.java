package courseratrainer;

public class Circle {
	double radius;
	
	public Circle() {
		double radius = 1.0;
	}
	public Circle (double radius) {
		this.radius = radius;
	}

}
