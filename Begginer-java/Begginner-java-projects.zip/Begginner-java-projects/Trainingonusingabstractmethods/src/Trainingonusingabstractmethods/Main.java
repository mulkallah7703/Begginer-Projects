package Trainingonusingabstractmethods;

class Addition {
	public int add(int number1, int number2) {
		Addition obj = new Addition();
		int result = obj.add(5, 10);
		return result;
	}
}

public class Main {
	public static void main (String[] args) {
		
	}

}
