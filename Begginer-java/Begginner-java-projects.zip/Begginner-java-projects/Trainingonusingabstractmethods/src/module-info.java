/**
 * 
 */
/**
 * 
 */
module Trainingonusingabstractmethods {
}