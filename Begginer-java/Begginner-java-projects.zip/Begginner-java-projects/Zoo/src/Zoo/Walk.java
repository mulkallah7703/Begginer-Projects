package Zoo;

public interface Walk {

    /** TODO 4 Solution: declare a functionality or method named
     *                  "walking" with return type "void"
     **/
    public void  walking() ;
    /** TODO 4 Solution End **/

}

