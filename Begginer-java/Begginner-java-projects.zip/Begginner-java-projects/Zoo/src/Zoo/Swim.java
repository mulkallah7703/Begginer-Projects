package Zoo;

public interface Swim {
    public void swimming();
}
