package com.lesson.lab;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SeatBooking {
    private List<Seat> bookedSeatsList;

    public SeatBooking() {
        this.bookedSeatsList = new ArrayList<>();
    }

    public void addNewBooking(String seatNumber) {
        for (Seat seat : bookedSeatsList) {
            if (seat.getSeatNumber().equals(seatNumber) && seat.isBooked() && !seat.isCanceled()) {
                System.out.println("This seat is already booked.");
                return;
            }
        }

        Seat newSeat = new Seat(seatNumber);
        newSeat.setBooked(true);
        newSeat.setBookingDate(new Date());
        bookedSeatsList.add(newSeat);
        System.out.println("Seat " + seatNumber + " has been successfully booked!");
    }

    public void cancelBooking(String seatNumber) {
        boolean found = false;
        for (Seat seat : bookedSeatsList) {
            if (seat.getSeatNumber().equals(seatNumber)) {
                bookedSeatsList.remove(seat);
                System.out.println("Seat " + seatNumber + " has been successfully removed!");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("No booking found for seat " + seatNumber + ".");
        }
    }

    public void updateBooking(String oldSeatNumber, String newSeatNumber) {
        boolean found = false;
        for (Seat seat : bookedSeatsList) {
            if (seat.getSeatNumber().equals(oldSeatNumber)) {
                seat.setBooked(false);
                bookedSeatsList.remove(seat);
                addNewBooking(newSeatNumber);
                System.out.println("Seat " + oldSeatNumber + " has been updated to " + newSeatNumber + "!");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("No booking found for seat " + oldSeatNumber + ".");
        }
    }

    public void displayBookings() {
        if (bookedSeatsList.isEmpty()) {
            System.out.println("No bookings have been made yet.");
            return;
        }

        System.out.println("All bookings:");
        for (Seat seat : bookedSeatsList) {
            if (seat.isBooked() && !seat.isCanceled()) {
                System.out.println("Seat Number: " + seat.getSeatNumber());
            }
        }
    }
}
