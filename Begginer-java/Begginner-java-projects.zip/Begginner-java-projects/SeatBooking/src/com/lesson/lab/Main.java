package com.lesson.lab;

public class Main {
    public static void main(String[] args) {
        SeatBooking bookingManager = new SeatBooking();

        // 1. حجز المقاعد A1، A2، A3
        bookingManager.addNewBooking("A1");
        bookingManager.addNewBooking("A2");
        bookingManager.addNewBooking("A3");

        // 2. عرض جميع الحجوزات
        bookingManager.displayBookings();

        // 3. إلغاء المقعد A2
        bookingManager.cancelBooking("A2");

        // 4. عرض الحجوزات بعد الإلغاء
        System.out.println("All bookings after removal:");
        bookingManager.displayBookings();

        // 5. تحديث A1 إلى B1
        bookingManager.updateBooking("A1", "B1");

        // 6. عرض الحجوزات بعد التحديث
        System.out.println("All bookings after update:");
        bookingManager.displayBookings();
    }
}
