package TextEditorUndo;

public class TextEditorUndo {
    private int[] stack;
    private int top;

    // Constructor to initialize the stack and top index
    public TextEditorUndo(int size) {
        // TODO 1: initialize the stack array
    	stack = new int [10];
        // TODO 2: set initial top index to -1
    	top = -1;
    }

    // Method to add a new action to the stack
    public void push(int action) {
        // TODO 3: check if the stack is full
    	if (top == stack.length -1) {
    		System.out.println("Stack is full cannot push: "+ action); // TODO 4: print message if the stack is full
    		
    	}else {
    		stack[++top] = action; // TODO 5: increment top and add action to the stack
    		
    		System.out.println(action + "  has been pushed to the stack");// TODO 6: print confirmation message
    	}
    }
    // Method to remove and return the most recent action from the stack
    public int pop() {
        // TODO 7: Check if the stack is empty
    	if (top == stack.length -1) {
    		System.out.println("Is the stack is empty ! Cannot pop");
    		return (Integer) null;// TODO 8: Print message if the stack is empty and return null
    	}else {
    		int poppedvalue = stack [top--]; // TODO 9: Retrieve and remove the top action from the stack
    		System.out.println("Popped element: " + poppedvalue);
    		return poppedvalue;// TODO 10: Print confirmation message, return and replace empty string with the undone action
    	}

    }
    // Method to view the most recent action in the stack without removing it
    public Object peek() {
         if  (top == -1){ // TODO 11: Check if the stack is empty
        	 System.out.println("the stack is empity "); // TODO 12: Print message if the stack is empty and return null
        	 return null;
         }else {
        	 System.out.println("Top element is: " + stack[top]);
        	 return stack[top];
         }

    }

    // Method to display all actions in the stack
    public void display() {
        // TODO 14: check if the stack is empty by verifying if top is -1.
        if (top == -1) {
            // TODO 15: print a message indicating no actions to display.
            System.out.println("Stack is empty. No actions to display.");
        } else {
            // TODO 16: iterate through the stack from 0 to top and print each action.
            System.out.println("Current stack:");
            for (int i = 0; i <= top; i++) {
                System.out.print(stack[i] + " ");
            }
            // TODO 17: print a new line after displaying all actions for better formatting.
            System.out.println();
        }
    }


	public void push(String action) {
		// TODO Auto-generated method stub
		
	}
}