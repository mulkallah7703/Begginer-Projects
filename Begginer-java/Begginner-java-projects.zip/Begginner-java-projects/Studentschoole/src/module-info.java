/**
 * 
 */
/**
 * 
 */
module Studentschoole {
}