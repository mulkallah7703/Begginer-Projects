package Studentschoole;

public class Address {
	String street;
	String city;
	String state;
	

}
