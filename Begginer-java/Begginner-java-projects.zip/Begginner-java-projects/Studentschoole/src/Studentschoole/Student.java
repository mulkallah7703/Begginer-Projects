package Studentschoole;

public class Student {
	int studentId;
	String firstName;
	String middleName;
	String lastName;
	String street;
	String city;
	String State;
	String nameofSubject;
	String subjectId;
	int credits;
	double  percentage;
	
	Student {
		NameOfStudent name;
		Address addressForCorrespondence;
		Subject subject;
		double percentage;
	}

}

