package StepOfTreasureHunt;
import java.util.LinkedList;

public class TreasureHunt {
	public static void main(String[] args) {
		LinkedList<String> clues = new LinkedList<>();
		
		clues.add("Check inside the mailbox");
		clues.add("Go to the fountain in the tree");
		clues.add("Look for the Oak tree");
		System.out.println(clues);
		
		clues.set(2, "Look behind the old Oak tree");
		System.out.println("Updated clues : " + clues);
		
		String firstClue = clues.get(0);
		System.out.println("First clue:" + firstClue);
		
		String SecondClue = clues.get(1);
		System.out.println("Second clue:" + SecondClue);
		
		clues.removeLast();
		System.out.println(clues);
		
		clues.remove(1);
		System.out.println(clues);
		
	}

}
