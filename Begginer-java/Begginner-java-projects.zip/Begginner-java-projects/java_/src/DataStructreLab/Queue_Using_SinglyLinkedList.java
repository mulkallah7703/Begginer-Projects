package DataStructreLab;
//Exercise 5 lap 8

//Exercise 5 lab 8

import java.util.LinkedList;

class JavaLinkedList {
 LinkedList list1;

 JavaLinkedList() {
     list1 = new LinkedList();
 }

 public void enqueue(Object x) {
     list1.add(x); // add at end
 }

 public Object dequeue() { // remove from front
     if (list1.size() > 0)
         return (list1.remove(0));
     else
         return "null";
 }

 public Object first() {
     return (list1.get(0));
 }

 public void printQueue() {
     System.out.println(" " + list1.toString());
 }
}

////////////////////////////////////

public class Queue_Using_SinglyLinkedList {
 public static void main(String[] ar) {
     double x = 10.0;
     JavaLinkedList linkedListQueue = new JavaLinkedList();
     
     System.out.println("Enqueue some values...");
     linkedListQueue.enqueue(x);
     linkedListQueue.enqueue(x + 2);
     linkedListQueue.enqueue(x + 4);
     linkedListQueue.enqueue(x + 6);
     
     System.out.println("\nPrint queue:");
     linkedListQueue.printQueue();
     
     System.out.println("\nFirst = " + linkedListQueue.first());
     
     System.out.println("\nDequeue one value:");
     System.out.println("Dequeued " + linkedListQueue.dequeue());
     
     System.out.println("\nPrint queue:");
     linkedListQueue.printQueue();
 }
}


