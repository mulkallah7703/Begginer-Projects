package DataStructreLab;
//Exercise 2 lap 8
class myCircAryQueue{ 
int front, rear , size, count; 
double [] values ; 
myCircAryQueue(int n){ 
values = new double [n] ; 
front = rear = count = 0; 
size = n ; 
} 
public void enqueue(double x){ // rear is pointing to next free position 
if( ! isFull( ) ) { 
values[rear] = x; 
rear = (rear+1) % size; 
count++; 
} 
} 
public double dequeue( ) { 
if( ! isEmpty( ) ){ 
double e = values [front]; 
front = (front+1) % size; 
count--; 
return e; 
} 
return 0; 
} 
public boolean isFull(){ 
return (count == size); 
} 
public boolean isEmpty(){ 
return (count == 0); 
} 
public double first ( ){ 
if( ! isEmpty( ) ) 
return values[front]; 
return 0; 
} 
public void printQueue() { 
 for (int i = 0 ; i < count ; i++) 
 System.out.print(values[(front+i) % size] + " " ); 
 } 
} 

public class Queue_Using_Circular_Array {
	public static void main(String[] args) { 
		double x = 10.0; 
		myCircAryQueue aryQueue = new myCircAryQueue (4); 
		System.out.println("isEmpty ? " + aryQueue.isEmpty()); 
		System.out.println("Enqueue 4 values >0 .... "); 
		aryQueue.enqueue(x); 
		aryQueue.enqueue(x+2); 
		aryQueue.enqueue(x+4); 
		aryQueue.enqueue(x+6); 
		System.out.println("isFull ? " + aryQueue.isFull()); 
		System.out.println("\n Print the Queue :"); 
		aryQueue.printQueue(); 
		System.out.println("\n\n First = " + aryQueue.first() ); 
		System.out.println("\n Dequeue TWO value :"); 
		x = aryQueue.dequeue();
		double y = aryQueue.dequeue(); 
		System.out.println("Dequeued " + x + " and " + y); 
		 
		System.out.println("Can enQ 2 more ?: isFull ?" + aryQueue.isFull()); 
		aryQueue.enqueue(x+8); 
		aryQueue.enqueue(x+10); 
		System.out.println("\n Print the Queue :"); 
		aryQueue.printQueue(); 
		} 
		} 



