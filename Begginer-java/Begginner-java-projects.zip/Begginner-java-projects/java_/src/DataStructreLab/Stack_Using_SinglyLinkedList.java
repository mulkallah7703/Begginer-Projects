package DataStructreLab;
//Exercise 5 lap 7
class Node{
	public int info;
	public String name;
	public double cgpa;
	public Node next;
	
	public Node(int i, String nm, double g) {
		info = i; name = nm; cgpa = g;
	}
}
class mySLL_Stack{
	protected Node head, tail;
	public mySLL_Stack() {
		head = tail = null;
	}
	public void push( int el, String nm, double g) {
		Node newNode = new Node(el, nm, g);
		if (head == null)
			tail = head = newNode;
		else {
			newNode.next = head; 
			head = newNode;
			
		}
		
	}
	public int pop() {
		if ( head == null) 
			return -1;
		int el = head.info;
		if (head == tail ) 
			head = tail = null;
		else 
			head = head.next;
		return el;
	}
	public int peek() {
		if ( head == null)
			return -1;
		else return head.info;
	}
	public void printAll() {
		for (Node tmp = head; tmp != null; tmp = tmp.next)
			System.out.println(tmp.info + "" + tmp.name + "" + tmp.cgpa);
	}
	public boolean search (int el) {
		Node tmp = head; 
		while (tmp !=null && tmp.info != el)
			tmp = tmp.next;
		return tmp != null;
	}
}
public class Stack_Using_SinglyLinkedList {
	public static void main(String[] args) {
		mySLL_Stack sllStack = new mySLL_Stack();
		int x = 2020;
		System.out.println("Push some values...");
		sllStack.push(2019, "Zain", 2.50);
		sllStack.push(2020, "Ahmed", 2.75);
		sllStack.push(2022, "Majid", 2.95);
		
		
		System.out.println("\n Print Stack:");
		sllStack.printAll();
		System.out.println("\n Peek = " + sllStack.peek());
		System.out.println("\n Pop one value:");
		System.out.println("Poped " + sllStack.pop());
		System.out.println("\n print stack:");
		System.out.println("\n Search for " + x);
		System.out.println("Found? " + sllStack.search(x));
	}

}
