package DataStructreLab;
//task 1 lap11
import java.util.*;

public class DijkstraAlgorithm {
    static class Edge {
        int dest, weight;
        Edge(int dest, int weight) {
            this.dest = dest;
            this.weight = weight;
        }
    }

    static class Graph {
        int V;
        List<List<Edge>> adj;

        Graph(int V) {
            this.V = V;
            adj = new ArrayList<>();
            for (int i = 0; i < V; i++) {
                adj.add(new ArrayList<>());
            }
        }

        void addEdge(int src, int dest, int weight) {
            adj.get(src).add(new Edge(dest, weight));
            adj.get(dest).add(new Edge(src, weight)); // If undirected graph
        }

        void dijkstra(int src) {
            int[] dist = new int[V];
            boolean[] visited = new boolean[V];
            Arrays.fill(dist, Integer.MAX_VALUE);
            dist[src] = 0;

            for (int count = 0; count < V - 1; count++) {
                int u = minDistance(dist, visited);
                visited[u] = true;

                for (Edge edge : adj.get(u)) {
                    if (!visited[edge.dest] && dist[u] != Integer.MAX_VALUE && dist[u] + edge.weight < dist[edge.dest]) {
                        dist[edge.dest] = dist[u] + edge.weight;
                    }
                }
            }

            System.out.println("Vertex \t Distance from Source");
            for (int i = 0; i < V; i++) {
                System.out.println(i + " \t " + dist[i]);
            }
        }

        int minDistance(int[] dist, boolean[] visited) {
            int min = Integer.MAX_VALUE, min_index = -1;
            for (int v = 0; v < V; v++) {
                if (!visited[v] && dist[v] <= min) {
                    min = dist[v];
                    min_index = v;
                }
            }
            return min_index;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of vertices: ");
        int V = sc.nextInt();
        Graph g = new Graph(V);

        System.out.print("Enter number of edges: ");
        int E = sc.nextInt();

        for (int i = 0; i < E; i++) {
            System.out.print("Enter source, destination, and weight for edge " + (i+1) + ": ");
            int src = sc.nextInt();
            int dest = sc.nextInt();
            int weight = sc.nextInt();
            g.addEdge(src, dest, weight);
        }

        System.out.println("\nCalculating shortest paths from source node 0:");
        g.dijkstra(0);

        sc.close();
    }
}


