package DataStructreLab;
//Exercise 1 lap7
import java.util.ArrayList;

class JavaArrayList { 
    ArrayList list1; 

    JavaArrayList() { 
        list1 = new ArrayList(); 
    } 

    public void push(Object x) { // add at end
        list1.add(x); 
    } 

    public Object pop() { // remove from end
        if (list1.size() > 0)
            return (list1.remove(list1.size()-1));
        else
            return "null"; 
    } 

    public Object peek() { 
        return (list1.get(list1.size()-1)); 
    } 

    public void printStack() { 
        System.out.println(" " + list1.toString()); 
    }
}

//////////////////////////////////////

public class Stack_Using_Java_ArrayList { 
    public static void main(String[] ar) { 
        double x = 10.0; 
        JavaArrayList aryListStack = new JavaArrayList(); 

        System.out.println("Push some values...");
        aryListStack.push(x); 
        aryListStack.push(x+2); 
        aryListStack.push(x+4); 
        aryListStack.push(x+6); 

        System.out.println("\n Print stack :");
        aryListStack.printStack(); 

        System.out.println("\n Peek = " + aryListStack.peek() ); 
        System.out.println("\n pop one value :");
        System.out.println("popped = " + aryListStack.pop()); 

        System.out.println("\n Print stack :");
        aryListStack.printStack(); 
    }
}


	


