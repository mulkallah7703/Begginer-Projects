package DataStructreLab;

import java.util.Scanner;

public class searchLinBine {

    // Method to perform linear search on an array
    public static int linearSearch(int[] arr, int target) {
        // Iterate through the array
        for (int i = 0; i < arr.length; i++) {
            // Check if the current element matches the target
            if (arr[i] == target)
                return i; // Return the index if found
        }
        return -1; // Return -1 if the target is not found
    }

    /////////////////////////////////////

    // Method to perform binary search on a sorted array
    public static int binarySearch(int[] arr, int target) {
        int first = 0; // Starting index of the array
        int last = arr.length - 1; // Last index of the array

        // Continue searching while the range is valid
        while (first <= last) {
            int mid = (first + last) / 2; // Find the middle index

            // Check if the middle element is the target
            if (target == arr[mid])
                return mid; // Return the index if found

            // If the target is greater, search in the right half
            if (target > arr[mid])
                first = mid + 1;
            else // If the target is smaller, search in the left half
                last = mid - 1;
        }
        return -1; // Return -1 if the target is not found
    }

    ///////////////////////////////////////

    // Main method to test the search functions
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array size
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Initialize the array
        int[] array = new int[size];

        // Input array elements
        System.out.println("Enter " + size + " elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt(); // Read each element
        }

        // Input target integer
        System.out.print("Enter the target integer for linear search: ");
        int targetLinear = scanner.nextInt();
        // Perform linear search
        System.out.println("Linear Search @ = " + linearSearch(array, targetLinear));

        // Sort the array for binary search
        java.util.Arrays.sort(array);

        // Input target integer for binary search
        System.out.print("Enter the target integer for binary search: ");
        int targetBinary = scanner.nextInt();
        // Perform binary search
        System.out.println("Binary Search @ = " + binarySearch(array, targetBinary));

        scanner.close(); // Close the scanner
    }
}

