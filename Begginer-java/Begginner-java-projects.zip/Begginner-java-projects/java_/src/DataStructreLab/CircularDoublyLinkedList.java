package DataStructreLab;
class Node {
    public int info;
    public String name;
    public double cgpa;
    public Node next;
    public Node previous;

    public Node() { }
    public Node(int i, String nm, double g) {
        info = i;
        name = nm;
        cgpa = g;
    }
}

class myCircularDLL {
    protected Node head, tail;

    public myCircularDLL() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void addToHead(int el, String nm, double g) {
        Node newNode = new Node(el, nm, g);
        if (head == null) {
            head = tail = newNode;
            head.next = head.previous = head;
        } else {
            newNode.next = head;
            newNode.previous = tail;
            head.previous = newNode;
            tail.next = newNode;
            head = newNode;
        }
    }

    public void addToTail(int el, String nm, double g) {
        Node newNode = new Node(el, nm, g);
        if (head == null) {
            head = tail = newNode;
            head.next = head.previous = head;
        } else {
            newNode.previous = tail;
            newNode.next = head;
            tail.next = newNode;
            head.previous = newNode;
            tail = newNode;
        }
    }

    public boolean addBefore(int el, String nm, double g, int target) {
        if (head == null) return false;
        Node tmp = head;
        do {
            if (tmp.info == target) {
                Node newNode = new Node(el, nm, g);
                newNode.next = tmp;
                newNode.previous = tmp.previous;
                tmp.previous.next = newNode;
                tmp.previous = newNode;
                if (tmp == head) head = newNode;
                return true;
            }
            tmp = tmp.next;
        } while (tmp != head);
        System.out.println("Target not found");
        return false;
    }

    public int deleteFromHead() {
        if (head == null) return -1;
        int el = head.info;
        if (head == tail) {
            head = tail = null;
        } else {
            head = head.next;
            head.previous = tail;
            tail.next = head;
        }
        return el;
    }

    public int deleteFromTail() {
        if (head == null) return -1;
        int el = tail.info;
        if (head == tail) {
            head = tail = null;
        } else {
            tail = tail.previous;
            tail.next = head;
            head.previous = tail;
        }
        return el;
    }

    public boolean delete(int el) {
        if (head == null) return false;
        Node tmp = head;
        do {
            if (tmp.info == el) {
                if (head == tail) {
                    head = tail = null;
                } else {
                    tmp.previous.next = tmp.next;
                    tmp.next.previous = tmp.previous;
                    if (tmp == head) head = tmp.next;
                    if (tmp == tail) tail = tmp.previous;
                }
                return true;
            }
            tmp = tmp.next;
        } while (tmp != head);
        return false;
    }

    public void printAll() {
        if (head == null) {
            System.out.println("null");
            return;
        }
        Node tmp = head;
        System.out.print("null");
        do {
            System.out.print(" <- " + tmp.info + " " + tmp.name + " " + tmp.cgpa + " -> ");
            tmp = tmp.next;
        } while (tmp != head);
        System.out.println("null");
    }

    public void printAllReverse() {
        if (tail == null) {
            System.out.println("null");
            return;
        }
        Node tmp = tail;
        System.out.print("null");
        do {
            System.out.print(" <- " + tmp.info + " " + tmp.name + " " + tmp.cgpa + " -> ");
            tmp = tmp.previous;
        } while (tmp != tail);
        System.out.println("null");
    }

    public boolean isInList(int el) {
        if (head == null) return false;
        Node tmp = head;
        do {
            if (tmp.info == el) return true;
            tmp = tmp.next;
        } while (tmp != head);
        return false;
    }
}

public class CircularDoublyLinkedList {
    public static void main(String[] args) {
        myCircularDLL L1 = new myCircularDLL();

        System.out.println("Empty ? " + L1.isEmpty());

        L1.addToTail(2019, "Zain", 2.50);
        L1.addToHead(2020, "Ahmed", 2.75);
        L1.addToTail(2022, "Majid", 2.95);
        L1.addToHead(2021, "Khalid", 2.90);

        L1.printAll();

        int x = 2020;
        System.out.println("Found " + x + "  " + L1.isInList(x));
        System.out.println("addBefore " + x);
        L1.addBefore(2023, "Hamid", 2.00, x);
        L1.printAll();

        System.out.println("Delete from tail");
        L1.deleteFromTail();
        L1.printAll();

        System.out.println("Delete " + x);
        L1.delete(x);
        L1.printAll();

        System.out.println("Print in Reverse ");
        L1.printAllReverse();
    }
}



