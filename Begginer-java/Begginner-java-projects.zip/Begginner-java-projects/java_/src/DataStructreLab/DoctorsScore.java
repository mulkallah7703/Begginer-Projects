package DataStructreLab;

import java.util.Arrays;
import java.util.Comparator;

public class DoctorsScore {
    public static void main(String[] args) {
        // Array of doctors and their scores
        String[][] doctors = {
            {"Dr. Akhlaq", "42.0"},
            {"Dr. Marey", "41.0"},
            {"Dr. Zeshan", "40.0"},
            {"Dr. Musab", "39.0"}
        };

        // Sort the doctors array based on scores in descending order
        Arrays.sort(doctors, new Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                return Double.compare(Double.parseDouble(b[1]), Double.parseDouble(a[1]));
            }
        });

        // Print the header for output
        System.out.println("Output:");
        
        // Print each doctor's name and score in the required format
        for (String[] doctor : doctors) {
            System.out.printf("%s, %s%n", doctor[0], doctor[1]);
        }
    }
}
