package DataStructreLab;
//Task 1 lap 8
import java.util.Scanner;

class Node {
    int requestID;
    int priority;
    Node next;

    public Node(int id, int p) {
        requestID = id;
        priority = p;
        next = null;
    }
}

class PriorityQueue {
    private Node head;
    private int customerCounter = 0;

    public void addCustomer(int priority) {
        customerCounter++;
        Node newNode = new Node(customerCounter, priority);

        if (head == null || priority > head.priority) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.priority >= priority) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }

        System.out.println("Added customer # " + newNode.requestID);
    }

    public void removeCustomer() {
        if (head == null) {
            System.out.println("Queue is empty!");
            return;
        }
        System.out.println("Removed customer # " + head.requestID + "(" + head.priority + ")");
        head = head.next;
    }

    public void printQueue() {
        if (head == null) {
            System.out.println("Queue is empty!");
            return;
        }
        System.out.print("Queue = ");
        Node current = head;
        while (current != null) {
            System.out.print(current.requestID + "(" + current.priority + ")");
            if (current.next != null)
                System.out.print(", ");
            current = current.next;
        }
        System.out.println();
    }

	public void add(Node node) {
		// TODO Auto-generated method stub
		
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public Node poll() {
		// TODO Auto-generated method stub
		return null;
	}
}

public class OfficePriorityQueue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PriorityQueue queue = new PriorityQueue();
        int choice;

        do {
            System.out.println("\nPriority Queue");
            System.out.println("1. Add a customer");
            System.out.println("2. Remove a customer");
            System.out.println("3. Show the queue");
            System.out.println("4. Exit");
            System.out.print("Your choice? ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter priority? ");
                    int priority = sc.nextInt();
                    if (priority < 0 || priority > 10) {
                        System.out.println("Priority must be between 0 and 10!");
                    } else {
                        queue.addCustomer(priority);
                    }
                    break;
                case 2:
                    queue.removeCustomer();
                    break;
                case 3:
                    queue.printQueue();
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 4);

        sc.close();
    }
}




