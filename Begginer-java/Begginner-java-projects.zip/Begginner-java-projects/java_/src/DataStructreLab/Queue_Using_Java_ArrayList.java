package DataStructreLab;
//exercise 3 lap 8
import java.util.ArrayList; 
class JavaArrayList{ 
ArrayList list1; 
JavaArrayList(){ 
list1 = new ArrayList(); 
} 
public void enqueue(Object x) { 
 list1.add(x); // add at end 
 } 
 public Object dequeue( ) { 
 if ( list1.size() > 0 ) 
 return (list1.remove(0)); // remove from front 
 else 
 return "null"; 
 } 
 public Object first( ) { 
 return ( list1.get(0) ); 
 } 
public void printQueue() { 
System.out.println( " " + list1.toString() ); 
} 
} 
////////////////////////////// 

public class Queue_Using_Java_ArrayList {
	public static void main(String[] ar) { 
		double x = 10.0; 
		JavaArrayList aryListQueue = new JavaArrayList(); 
		System.out.println("Enqueue some values..."); 
		aryListQueue.enqueue(x); 
		aryListQueue.enqueue(x+2); 
		aryListQueue.enqueue(x+4); 
		aryListQueue.enqueue(x+6); 
		System.out.println("\n Print queue :"); 
		aryListQueue.printQueue();
		System.out.println("\n First = " + aryListQueue.first() ); 
		System.out.println("\n dequeue one value :"); 
		System.out.println("dequeueed " + aryListQueue.dequeue()); 
		System.out.println("\n Print queue :"); 
		aryListQueue.printQueue(); 
		} 
		} 


