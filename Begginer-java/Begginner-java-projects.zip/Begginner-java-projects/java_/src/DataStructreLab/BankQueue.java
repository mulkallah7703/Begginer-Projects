package DataStructreLab;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class BankQueue {

	    public static void main(String[] args) {
	        Queue<String> queue = new LinkedList<>();
	        Scanner scanner = new Scanner(System.in);
	        int choice;

	        do {
	            // Display menu
	            System.out.println("Queue in a Bank");
	            System.out.println("1. Add a customer");
	            System.out.println("2. Remove a customer");
	            System.out.println("3. Show the queue");
	            System.out.println("4. Exit");
	            System.out.print("Your choice? ");
	            choice = scanner.nextInt();
	            scanner.nextLine(); // Consume newline

	            switch (choice) {
	                case 1:
	                    // Add a customer
	                    System.out.print("Enter customer name: ");
	                    String customerName = scanner.nextLine();
	                    queue.add(customerName);
	                    System.out.println("Added customer: " + customerName);
	                    break;

	                case 2:
	                    // Remove a customer (from the front)
	                    if (!queue.isEmpty()) {
	                        String removedCustomer = queue.poll(); // Remove from front
	                        System.out.println("Removed customer: " + removedCustomer);
	                    } else {
	                        System.out.println("No customers to remove.");
	                    }
	                    break;

	                case 3:
	                    // Show the queue
	                    System.out.println("Current queue: " + queue);
	                    break;

	                case 4:
	                    System.out.println("Exiting...");
	                    break;

	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }

	            System.out.println(); // Blank line for better readability

	        } while (choice != 4);

	        scanner.close();
	    }
	}

