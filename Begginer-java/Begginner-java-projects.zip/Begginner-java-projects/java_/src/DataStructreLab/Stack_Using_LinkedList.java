package DataStructreLab;
//Exercise 4 lap 7

import java.util.LinkedList;

class JavaLinkedList{
    LinkedList list1;
    
    JavaLinkedList(){
        list1 = new LinkedList();
    }
    
    public void push(Object o) {  // add at end
        list1.add(o);
    }
    
    public Object pop() {  // remove from end
        if ( list1.size() > 0 )
            return (list1.remove(list1.size()-1));
        else
            return "nil";
    }
    
    public Object peek() {
        return ( list1.get(list1.size()-1) );
    }
    
    public void printStack() {
        System.out.println( "" + list1.toString() );
    }

	public void push(int o) {
		// TODO Auto-generated method stub
		
	}

	public void push(int o) {
		// TODO Auto-generated method stub
		
	}

	public void push(int o) {
		// TODO Auto-generated method stub
		
	}
}

public class Stack_Using_LinkedList {
    public static void main(String[] ar) {
        JavaLinkedList linkedListStack = new JavaLinkedList();
        
        System.out.println("Push some values...");
        linkedListStack.push(10);
        linkedListStack.push(15);
        linkedListStack.push(22);
        linkedListStack.push(46);
        
        System.out.println("\n Print stack :");
        linkedListStack.printStack();
        
        System.out.println("\n Peek = " + linkedListStack.peek() );
        
        System.out.println("\n Pop one value :");
        System.out.println("Poped = " + linkedListStack.pop());
        
        System.out.println("\n Print stack :");
        linkedListStack.printStack();
    }
}

