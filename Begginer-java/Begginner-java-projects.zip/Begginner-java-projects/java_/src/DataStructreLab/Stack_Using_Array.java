package DataStructreLab;
//Exercise 2 lap7
class myArrayStack { 
    int top = -1, size; 
    double [] values; 

    myArrayStack(int n) { 
        values = new double [n]; 
        top = -1; 
        size = n; 
    } 

    public void push(double x) { 
        if (top < size-1) { // not full 
            top++; 
            values[top] = x; 
        } 
    } 

    public double pop() { 
        double retval = 0.0; 
        if (top != -1) { // if not empty 
            retval = values[top]; 
            top--; 
        } 
        return retval; 
    } 

    public double peek() { 
        return values[top]; 
    } 

    public void printStack() { 
        for (int i = top ; i >= 0; i--) 
            System.out.println(values[i]); 
    } 
}

//////////////////////////////////////

public class Stack_Using_Array { 
    public static void main(String[] args) { 
        double x = 10.0; 
        myArrayStack aryStack = new myArrayStack (20); 

        System.out.println("Push some values..."); 
        aryStack.push(x); 
        aryStack.push(x+2); 
        aryStack.push(x+4); 
        aryStack.push(x+6); 

        System.out.println("\n Print stack :"); 
        aryStack.printStack(); 

        System.out.println("\n Peek = " + aryStack.peek() ); 

        System.out.println("\n Pop one value :"); 
        x = aryStack.pop(); 
        System.out.println("popped = " + x); 

        System.out.println("\n Print stack :"); 
        aryStack.printStack(); 
    } 
}

