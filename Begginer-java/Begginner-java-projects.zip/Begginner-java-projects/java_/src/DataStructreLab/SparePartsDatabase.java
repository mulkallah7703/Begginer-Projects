package DataStructreLab;
//Task 1 lap9
import java.util.Scanner;

class Node {
    int itemNo;
    double price;
    String description;
    Node left, right;

    public Node(int itemNo, double price, String description) {
        this.itemNo = itemNo;
        this.price = price;
        this.description = description;
        left = right = null;
    }
}

class BSTSpareParts {
    Node root;

    public void insert(int itemNo, double price, String description) {
        root = insertRec(root, itemNo, price, description);
    }

    private Node insertRec(Node root, int itemNo, double price, String description) {
        if (root == null) {
            root = new Node(itemNo, price, description);
            return root;
        }
        if (itemNo < root.itemNo)
            root.left = insertRec(root.left, itemNo, price, description);
        else if (itemNo > root.itemNo)
            root.right = insertRec(root.right, itemNo, price, description);
        return root;
    }

    public void search(int itemNo) {
        Node result = searchRec(root, itemNo);
        if (result != null)
            System.out.println("Found: " + result.itemNo + " " + result.price + " " + result.description);
        else
            System.out.println("Item not found.");
    }

    private Node searchRec(Node root, int itemNo) {
        if (root == null || root.itemNo == itemNo)
            return root;
        if (itemNo < root.itemNo)
            return searchRec(root.left, itemNo);
        return searchRec(root.right, itemNo);
    }

    public void delete(int itemNo) {
        root = deleteRec(root, itemNo);
    }

    private Node deleteRec(Node root, int itemNo) {
        if (root == null)
            return root;
        if (itemNo < root.itemNo)
            root.left = deleteRec(root.left, itemNo);
        else if (itemNo > root.itemNo)
            root.right = deleteRec(root.right, itemNo);
        else {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;
            root.itemNo = minValue(root.right);
            root.right = deleteRec(root.right, root.itemNo);
        }
        return root;
    }

    private int minValue(Node root) {
        int minv = root.itemNo;
        while (root.left != null) {
            minv = root.left.itemNo;
            root = root.left;
        }
        return minv;
    }

    public void inorder() {
        inorderRec(root);
    }

    private void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.itemNo + " " + root.price + " " + root.description);
            inorderRec(root.right);
        }
    }
}

public class SparePartsDatabase {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BSTSpareParts tree = new BSTSpareParts();
        int choice;

        do {
            System.out.println("\nSpare Parts Database");
            System.out.println("1. Insert item");
            System.out.println("2. Search item");
            System.out.println("3. Delete item");
            System.out.println("4. Show all items");
            System.out.println("5. Exit");
            System.out.print("Your choice? ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter item number: ");
                    int itemNo = sc.nextInt();
                    System.out.print("Enter price: ");
                    double price = sc.nextDouble();
                    sc.nextLine(); // Consume newline
                    System.out.print("Enter description: ");
                    String description = sc.nextLine();
                    tree.insert(itemNo, price, description);
                    break;
                case 2:
                    System.out.print("Enter item number to search: ");
                    itemNo = sc.nextInt();
                    tree.search(itemNo);
                    break;
                case 3:
                    System.out.print("Enter item number to delete: ");
                    itemNo = sc.nextInt();
                    tree.delete(itemNo);
                    break;
                case 4:
                    System.out.println("All items:");
                    tree.inorder();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 5);

        sc.close();
    }
}





