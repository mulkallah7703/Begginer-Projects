package DataStructreLab;
import java.io.*; 
import java.util.LinkedList; 

public class TestLinkedList {


	    public static void main(String[] ar) { 
	        // Creating a LinkedList
	        LinkedList<Integer> lst1 = new LinkedList<>(); // lst1 = [] 
	        lst1.addFirst(4); // lst1 = [4] 
	        lst1.addFirst(5); // lst1 = [5, 4] 
	        lst1.addLast(6); // lst1 = [5, 4, 6] 
	        lst1.addLast(5); // lst1 = [5, 4, 6, 5] 

	        // Displaying the current state of lst1
	        System.out.println("lst1: " + lst1); // lst1 = [5, 4, 6, 5] 

	        // Finding the last and first occurrence of 5 in lst1
	        System.out.println(lst1.lastIndexOf(5)); // 3 
	        System.out.println(lst1.indexOf(5)); // 0 
	        System.out.println(lst1.indexOf(7)); // -1 (7 is not in lst1)

	        // Removing the first occurrence of 5 from lst1
	        lst1.remove(Integer.valueOf(5)); // lst1 = [4, 6, 5] 

	        // Creating another LinkedList lst2 from lst1
	        LinkedList<Integer> lst2 = new LinkedList<>(lst1); // lst2 = [4, 6, 5] 

	        // Adding and removing elements in lst2
	        lst2.add(2, 8); // lst2 = [4, 6, 8, 5] 
	        lst2.remove(Integer.valueOf(5)); // lst2 = [4, 6, 8] 
	        lst2.remove(1); // lst2 = [4, 8] 

	        // Displaying the first and last elements of lst2
	        System.out.println(lst2.getFirst() + " " + lst2.getLast()); // 4 8 

	        // Setting the value at index 1 to 7 and displaying the previous value
	        System.out.println(lst2.set(1, 7)); // 8, lst2=[4, 7] 

	        // Creating an array b and displaying its contents
	        Integer[] b = {1, 2}; // b = [1, 2] 
	        for (int i = 0; i < b.length; i++) 
	            System.out.print(b[i] + " "); 
	        System.out.println(); 

	        // Converting lst2 to array b
	        Integer[] a1 = lst2.toArray(b); // a1 = b = [4, 7] 
	        for (int i = 0; i < b.length; i++) 
	            System.out.print(b[i] + " "); 
	        System.out.println(); 

	        // Converting lst1 to array b
	        a1 = lst1.toArray(b); // a1 = [4, 6, 5], b = [4, 7] 
	        for (int i = 0; i < b.length; i++) 
	            System.out.print(b[i] + " "); 
	        System.out.println(); 

	        // Displaying the contents of a1
	        for (int i = 0; i < a1.length; i++) 
	            System.out.print(a1[i] + " "); 
	        System.out.println(); 

	        // Converting lst1 to an Object array a2
	        Object[] a2 = lst1.toArray(); 
	        for (int i = 0; i < a2.length; i++) // a2 = [4, 6, 5] 
	            System.out.print(a2[i] + " "); // 4 6 5 
	        System.out.println(); 

	        // Displaying elements of lst1 using size and get methods
	        for (int i = 0; i < lst1.size(); i++) 
	            System.out.print(lst1.get(i) + " "); // 4 6 5 
	        System.out.println(); 

	        // Displaying elements of lst1 using an Iterator
	        for (java.util.Iterator<Integer> it = lst1.iterator(); it.hasNext(); ) 
	            System.out.print(it.next() + " "); // 4 6 5 
	        System.out.println(); 
	    } 
	}



