package DataStructreLab;
//task 2 lap9
import java.util.Scanner;

class WordNode {
    String word;
    String meaning;
    WordNode left, right;

    public WordNode(String word, String meaning) {
        this.word = word;
        this.meaning = meaning;
        left = right = null;
    }
}

class BSTDictionary {
    WordNode root;

    public void insert(String word, String meaning) {
        root = insertRec(root, word, meaning);
    }

    private WordNode insertRec(WordNode root, String word, String meaning) {
        if (root == null) {
            root = new WordNode(word, meaning);
            return root;
        }
        if (word.compareTo(root.word) < 0)
            root.left = insertRec(root.left, word, meaning);
        else if (word.compareTo(root.word) > 0)
            root.right = insertRec(root.right, word, meaning);
        return root;
    }

    public void search(String word) {
        WordNode result = searchRec(root, word);
        if (result != null)
            System.out.println("Found: " + result.word + " - " + result.meaning);
        else
            System.out.println("Word not found.");
    }

    private WordNode searchRec(WordNode root, String word) {
        if (root == null || root.word.equals(word))
            return root;
        if (word.compareTo(root.word) < 0)
            return searchRec(root.left, word);
        return searchRec(root.right, word);
    }

    public void delete(String word) {
        root = deleteRec(root, word);
    }

    private WordNode deleteRec(WordNode root, String word) {
        if (root == null)
            return root;
        if (word.compareTo(root.word) < 0)
            root.left = deleteRec(root.left, word);
        else if (word.compareTo(root.word) > 0)
            root.right = deleteRec(root.right, word);
        else {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;
            root.word = minValue(root.right);
            root.right = deleteRec(root.right, root.word);
        }
        return root;
    }

    private String minValue(WordNode root) {
        String minv = root.word;
        while (root.left != null) {
            minv = root.left.word;
            root = root.left;
        }
        return minv;
    }

    public void inorder() {
        inorderRec(root);
    }

    private void inorderRec(WordNode root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.word + " - " + root.meaning);
            inorderRec(root.right);
        }
    }
}

public class DictionaryDatabase {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BSTDictionary dict = new BSTDictionary();
        int choice;

        do {
            System.out.println("\nDictionary Database");
            System.out.println("1. Insert word");
            System.out.println("2. Search word");
            System.out.println("3. Delete word");
            System.out.println("4. Show all words");
            System.out.println("5. Exit");
            System.out.print("Your choice? ");
            choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter word: ");
                    String word = sc.nextLine();
                    System.out.print("Enter meaning: ");
                    String meaning = sc.nextLine();
                    dict.insert(word, meaning);
                    break;
                case 2:
                    System.out.print("Enter word to search: ");
                    word = sc.nextLine();
                    dict.search(word);
                    break;
                case 3:
                    System.out.print("Enter word to delete: ");
                    word = sc.nextLine();
                    dict.delete(word);
                    break;
                case 4:
                    System.out.println("All words:");
                    dict.inorder();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 5);

        sc.close();
    }
}



