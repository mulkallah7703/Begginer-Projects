package DataStructreLab;
import java.util.Scanner;

public class SortingAlgrothims {



	    // Method to perform Bubble Sort
	    public static void bubbleSort(int[] arr) {
	        int n = arr.length;
	        for (int i = 0; i < n - 1; i++) {
	            for (int j = 0; j < n - i - 1; j++) {
	                if (arr[j] > arr[j + 1]) {
	                    // Swap arr[j] and arr[j+1]
	                    int temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
	                }
	            }
	        }
	    }

	    // Method to perform Selection Sort
	    public static void selectionSort(int[] arr) {
	        int n = arr.length;
	        for (int i = 0; i < n - 1; i++) {
	            int minIndex = i;
	            for (int j = i + 1; j < n; j++) {
	                if (arr[j] < arr[minIndex]) {
	                    minIndex = j; // Update minIndex if a smaller element is found
	                }
	            }
	            // Swap the found minimum element with the first element
	            int temp = arr[minIndex];
	            arr[minIndex] = arr[i];
	            arr[i] = temp;
	        }
	    }

	    // Method to display the array
	    public static void displayArray(int[] arr) {
	        for (int num : arr) {
	            System.out.print(num + " ");
	        }
	        System.out.println(); // Print a new line
	    }

	    // Main method to execute the program
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Input array size
	        System.out.print("Enter the size of the array: ");
	        int size = scanner.nextInt();

	        // Initialize the array
	        int[] array = new int[size];

	        // Input array elements
	        System.out.println("Enter " + size + " elements of the array:");
	        for (int i = 0; i < size; i++) {
	            array[i] = scanner.nextInt(); // Read each element
	        }

	        // Input choice of sorting algorithm
	        System.out.println("Choose sorting algorithm:");
	        System.out.println("1. Bubble Sort");
	        System.out.println("2. Selection Sort");
	        System.out.print("Enter your choice (1 or 2): ");
	        int choice = scanner.nextInt();

	        // Sort the array based on user's choice
	        switch (choice) {
	            case 1:
	                bubbleSort(array);
	                System.out.println("Array sorted using Bubble Sort:");
	                break;
	            case 2:
	                selectionSort(array);
	                System.out.println("Array sorted using Selection Sort:");
	                break;
	            default:
	                System.out.println("Invalid choice. Please choose 1 or 2.");
	                scanner.close();
	                return; // Exit the program if the choice is invalid
	        }

	        // Display the sorted array
	        displayArray(array);
	        scanner.close(); // Close the scanner
	    }
	}



