package DataStructreLab;

public class searchLinBin {

    // Method to perform linear search on an array
    public static int linearSearch(int[] arr, int target) {
        // Iterate through the array
        for (int i = 0; i < arr.length; i++) {
            // Check if the current element matches the target
            if (arr[i] == target)
                return i; // Return the index if found
        }
        return -1; // Return -1 if the target is not found
    }

    /////////////////////////////////////

    // Method to perform binary search on a sorted array
    public static int binarySearch(int[] arr, int target) {
        int first = 0; // Starting index of the array
        int last = arr.length - 1; // Last index of the array

        // Continue searching while the range is valid
        while (first <= last) {
            int mid = (first + last) / 2; // Find the middle index

            // Check if the middle element is the target
            if (target == arr[mid])
                return mid; // Return the index if found

            // If the target is greater, search in the right half
            if (target > arr[mid])
                first = mid + 1;
            else // If the target is smaller, search in the left half
                last = mid - 1;
        }
        return -1; // Return -1 if the target is not found
    }

    ///////////////////////////////////////

    // Main method to test the search functions
    public static void main(String args[]) {
        // Sample array for linear search
        int[] array = {5, 15, 75, 50, 45, 5};
        // Perform linear search for the number 15
        System.out.println("Linear Search @ = " + linearSearch(array, 15));

        // Sample sorted array for binary search
        int[] arraySrtd = {5, 15, 25, 45, 50, 75};
        // Perform binary search for the number 45
        System.out.println("Binary Search @ = " + binarySearch(arraySrtd, 45));
    }
}

