package Datastructurelab;

import java.util.ArrayList; // Import the ArrayList class
import java.util.Iterator; // Import the Iterator interface

public class IteratorPatternDemo1 {
    public static void main(String args[]) {
        ArrayList<String> names = new ArrayList<>(); // Create an ArrayList to hold String objects
        
        // Add names to the ArrayList
        names.add("Dr. Akhlaq");
        names.add("Dr. Lawan");
        names.add("Dr. Marey");
        names.add("Dr. Zeshan");
        names.add("Dr. Musab");
        
        // Remove a name from the ArrayList
        names.remove("Dr. Lawan");
        
        // Create an Iterator to traverse the ArrayList
        Iterator<String> it = names.iterator();
        
        // Use the Iterator to print the remaining names
        while(it.hasNext()) {
            String obj = it.next(); // Get the next name
            System.out.println(obj); // Print the name
        }
    }
}

