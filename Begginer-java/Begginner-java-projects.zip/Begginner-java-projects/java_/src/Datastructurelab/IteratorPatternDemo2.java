package Datastructurelab;

//Custom Iterator interface
interface Iterator {
 public boolean hasNext(); // Check if there are more elements
 public Object next(); // Get the next element
}

//Custom Container interface
interface Container {
 public Iterator getIterator(); // Get an iterator for the container
}

//Class implementing the Container interface
class CollectionofNames implements Container {
 // Array of names
 public String name[] = {"Dr. Akhlaq", "Dr. Marey", "Dr. Zeshan", "Dr. Musab"};

 // Method to get the iterator
 @Override
 public Iterator getIterator() {
     return new CollectionofNamesIterate(); // Return the iterator instance
 }

 // Private inner class that implements the Iterator interface
 private class CollectionofNamesIterate implements Iterator {
     int i; // Index for iteration

     // Method to check if there are more elements
     @Override
     public boolean hasNext() {
         return (i < name.length); // Check if current index is less than length of array
     }

     // Method to return the next element
     @Override
     public Object next() {
         if (this.hasNext()) {
             return name[i++]; // Return the current name and increment index
         }
         return null; // Return null if no more elements
     }
 }
}

//Main class to demonstrate the iterator pattern
public class IteratorPatternDemo2 {
 public static void main(String[] args) {
     CollectionofNames cmpnyRepository = new CollectionofNames(); // Create an instance of CollectionofNames

     // Use the iterator to print the names
     for (Iterator iter = cmpnyRepository.getIterator(); iter.hasNext(); ) {
         String name = (String) iter.next(); // Get the next name
         System.out.println(name); // Print the name
     }
 }
}
