package myfirsrapp;

public class test {

int basic;
int travel;
int health;
void empsalary(int a, int b, int c) {
	System.out.println (a+b+c);
	}
public static void main(String[] args) {
	myfirsrapp s = new myfirsrapp ();
	s.empmyfirsrapp(2000, 500, 300);
}
}
