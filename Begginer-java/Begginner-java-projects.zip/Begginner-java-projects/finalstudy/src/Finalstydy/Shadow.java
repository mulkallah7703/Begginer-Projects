package Finalstydy;


public class Shadow {
	int a;
	int b;
	public Shadow (int a, int b) {
		this.a = a;
		this.b= b;
	
	}
	public static void main (String args[]) {
		Shadow s = new Shadow(37, 47);
		System.out.println("a = " +s.a);
		System.out.println("b = " +s.b);
	}

}
