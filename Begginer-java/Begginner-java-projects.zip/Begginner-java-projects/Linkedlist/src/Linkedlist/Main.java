package Linkedlist;

import com.lesson.lab.controller.DoublyLinkedPlaylistManager;
import com.lesson.lab.controller.SinglyLinkedPlaylistManager;
import com.lesson.lab.model.Song;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

}
