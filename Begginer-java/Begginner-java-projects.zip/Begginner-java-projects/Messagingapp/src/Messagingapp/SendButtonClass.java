package Messagingapp;

class SendButtonClass extends abstractButtonClass implements ButtonPress{
	String sendTo;
	String message;
	
	@Override
	public void buttonPress() {
		System.out.println("Sending"+ this.message +"to" +this.sendTo);
		// TODO Auto-generated method stub
		
	}
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
