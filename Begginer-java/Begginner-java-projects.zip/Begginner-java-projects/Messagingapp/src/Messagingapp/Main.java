package Messagingapp;

public class Main {
	public static void main (String[] args) {
		SendButtonClass sendButton = new SendButtonClass();
		sendButton.setCaption("Send");
		sendButton.setSendTo("mulk@gmail.com");
		sendButton.setMessage("Hello Mulk Allah");
		sendButton.buttonPress();
	}

}
