package Messagingapp;

abstract class abstractButtonClass {
	String caption;
	public void setCaption(String caption) {
		this.caption = caption;
	}
	public String getCaption() {
		return this.caption;
	}


}
