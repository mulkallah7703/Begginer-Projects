package Messagingapp;

interface ButtonPress {
		void buttonPress();
	}


