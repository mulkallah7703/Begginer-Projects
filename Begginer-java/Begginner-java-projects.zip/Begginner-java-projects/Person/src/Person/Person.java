package Person;

public abstract class Person {
	String name;
	Date dob;
	
	abstract void getDetails();

}
