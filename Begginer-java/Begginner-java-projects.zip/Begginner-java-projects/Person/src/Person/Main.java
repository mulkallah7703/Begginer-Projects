package Person;

public class Main {
    public static void main(String[] args) {
        Date dobOfStudent = new Date(1, 1, 2005);
        Date dobOfTeacher = new Date(10, 10, 1995);
        Date dateOfAppointment = new Date(1, 4, 2024);

        // Create Teacher
        Teacher teacher1 = new Teacher("Madhavan", dobOfTeacher, dateOfAppointment, "MTech", "Electronics");
        teacher1.setSalary(50000);

        // Create Student
        Student student = new Student("Belinda", dobOfStudent, teacher1.name, "Electronics");

        // Display Info
        teacher1.getDetails();
        student.getDetails();
    }
}
