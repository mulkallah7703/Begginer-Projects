package Person;

abstract class Employee extends Person {
	Date dateOfAppointment;
	double salary;
	
	abstract void setSalary(int sal);
	abstract int getSalary();

}
